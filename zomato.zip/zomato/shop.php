<?php include("navbar.php") ?>
<div class="offcanvas offcanvas-end" tabindex="-1" id="sign-in" aria-labelledby="offcanvasExampleLabel">
    <div class="offcanvas-header">
        <h5 class="offcanvas-title text-primary">Sign-in</h5>
        <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
    </div>
    <div class="offcanvas-body">
        <div class="col-md-12 col-sm-12 p-5">
            <h2 class="text-center text-danger">Register Here</h2>
            <hr>
            <form action="" method="post" onsubmit="return validation();">
                <div class="row mb-3">
                    <div class="col-3">
                        <label for="">Name</label>
                    </div>
                    <div class="col-9"><input type="text" name="fname" id="fname" class="form-control"
                            placeholder="Enter Name"></div>
                </div>
                <div class="row mb-3">
                    <div class="col-3">
                        <label for="">Email</label>
                    </div>
                    <div class="col-9"><input type="email" name="femail" id="femail" class="form-control"
                            placeholder="Enter Email"></div>
                </div>
                <div class="row mb-3">
                    <div class="col-3">
                        <label for="">Mobile</label>
                    </div>
                    <div class="col-9"><input type="tel" name="fmobile" id="fmobile" class="form-control"
                            placeholder="Enter Mobile No"></div>
                </div>
                <div class="row mb-3">
                    <div class="col-3">
                        <label for="">Subject</label>
                    </div>
                    <div class="col-9"><input type="text" name="fsubject" id="fsubject" class="form-control"
                            placeholder="Enter Subject"></div>
                </div>
                <div class="row mb-3">
                    <div class="col-3">
                        <label for="">Message</label>
                    </div>
                    <div class="col-9">
                        <textarea name="fmessage" id="fmessage" rows="4" placeholder="Enter Message"
                            class="form-control"></textarea>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12 text-center">
                        <button type="submit" class="btn btn-outline-primary btn-lg">Save</button>
                        <button type="reset" class="btn btn-outline-warning btn-lg">Reset</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
    <section class="grid text-white"
        style="background-image: url(img/card2.webp); opacity: 0.7; background-repeat: no-repeat;background-size: cover; ">
        <div class="content"
            style="display: grid; grid-template-columns: 50% auto;gap: 30px; align-items: center; justify-content:space-between; width: 100%;">
            <div class="content-left p-5">
                <div class="info" style="max-width: 100%; display: flex; flex-direction: column;">
                    <h2 style="font-size: 60px;font-family: sans-serif;margin-bottom: 30px;color: rgb(248, 108, 0);">
                        Order Your Best <br>Food Anytime</h2>
                    <p style="font-size: 23px;line-height: 2pc;font-family: sans-serif;margin-bottom: 30px;">Hey Our
                        delicious food is waiting for you,<br>We are always near to you with fresh item of food</p>
                </div>
                <button
                    style="padding: 10px 23px ; background-color: rgb(255, 85, 0);color: White; border: none; border-radius: 10px;margin-bottom: 15px;">Explore
                    Food</button>
            </div>
            <div class="content-right"></div>
        </div>
    </section>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
        <h1 style="color: red; font-family: 'Times New Roman'; font-weight: bold; text-align: center; margin-top: 20px;">
        Todays Special Menu</h1>
            <div class="scroll-container ">
                <img src="img/card1.avif" alt="Cinque Terre" width="240" height="150" class="rounded-circle">
                <img src="img/card2.webp" alt="Forest" width="240" height="150" class="rounded-circle">
                <img src="img/card3.jpg" alt="Northern Lights" width="240" height="150" class="rounded-circle">
                <img src="img/card4.jpg" alt="Mountains" width="240" height="150" class="rounded-circle">
                <img src="img/card5.jpg" alt="Cinque Terre" width="240" height="150" class="rounded-circle">
                <img src="img/bar7.jpg" alt="Forest" width="240" height="150" class="rounded-circle">
                <img src="img/bar1.jfif" alt="Northern Lights" width="240" height="150" class="rounded-circle">
                <img src="img/bar2.jfif" alt="Mountains" width="240" height="150" class="rounded-circle">
                <img src="img/bar3.jfif" alt="Cinque Terre" width="240" height="150" class="rounded-circle">
                <img src="img/bar4.jfif" alt="Forest" width="240" height="150" class="rounded-circle">
                <img src="img/bar5.jpg" alt="Northern Lights" width="240" height="150" class="rounded-circle">
                <img src="img/bar6.webp" alt="Mountains" width="240" height="150" class="rounded-circle">
            </div>
        </div>
    </div>
 </div>
<div class="container mt-3">
    <!-- Nav tabs -->
    <ul class="nav nav-tabs" role="tablist">
        <li class="nav-item">
            <a class="nav-link active" data-bs-toggle="tab" href="#veg">Veg</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-bs-toggle="tab" href="#nonveg">Nonveg</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-bs-toggle="tab" href="#drinks">Drinks</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-bs-toggle="tab" href="#NYE">NYE</a>
        </li>
    </ul>
    <h1 style="text-align: center;font-family: 'Times New Roman';margin-top: 20px;">Veg Food</h1>
    <div class="tab-content">
        <div id="veg" class="container tab-pane active">
            <div class="row">
                <?php 
            $select="select * from shop WHERE category='veg' order by shopid desc ";
            $res=mysqli_query($con,$select);
            while($row=mysqli_fetch_assoc($res)){
            ?>
                <div class="col-md-3 col-sm-12 mb-sm-3">
                <div class="card" style="border: none;">
                        <img src="admin/<?php echo $row['image']; ?>" class="card-img-top" alt="..."
                            style="height:140px !important; width:252px !important; paddding:50px; !important;">
                        <div class="card-body text-center">
                            <h5 class="card-title text-danger"><?php echo $row['foodname']; ?></h5>
                            <h6 class="card-subtitle mb-2 text-muted "><b style="font-size:20px;"><i
                                        class="fa fa-inr"></i> <?php echo $row['price']; ?>/-</b></h6>
                            <a class="btn btn-success" href=""><i class="fa fa-whatsapp"></i> Order Now</a>
                        </div>
                    </div>
                </div>
                <?php } ?>
            </div>
            </div>
            <h1 style="text-align: center;font-family: 'Times New Roman';margin-top: 30px;">NonVeg Food</h1>
            <div id="nonveg" class="container tab-pane active">
            <div class="row">
                <?php 
            $select="select * from shop WHERE category='Nonveg' order by shopid desc";
            $res=mysqli_query($con,$select);
            while($row=mysqli_fetch_assoc($res)){
            ?>
                <div class="col-md-3 col-sm-12 mb-sm-3">
                <div class="card" style="border: none;">
                        <img src="admin/<?php echo $row['image']; ?>" class="card-img-top" alt="..."
                            style="height:140px !important; width:252px !important; paddding:50px; !important;">
                        <div class="card-body text-center">
                            <h5 class="card-title text-danger"><?php echo $row['foodname']; ?></h5>
                            <h6 class="card-subtitle mb-2 text-muted "><b style="font-size:20px;"><i
                                        class="fa fa-inr"></i> <?php echo $row['price']; ?>/-</b></h6>
                            <a class="btn btn-success" href=""><i class="fa fa-whatsapp"></i> Order Now</a>
                        </div>
                    </div>
                </div>
                <?php } ?>
            </div>
            </div>
            <h1 style="text-align: center;font-family: 'Times New Roman';margin-top: 30px;">Drinks</h1>
            <div id="drinks" class="container tab-pane active">
            <div class="row">
                <?php 
            $select="select * from shop WHERE category='drink' order by shopid desc";
            $res=mysqli_query($con,$select);
            while($row=mysqli_fetch_assoc($res)){
            ?>
                <div class="col-md-3 col-sm-12 mb-sm-3">
                <div class="card" style="border: none;">
                        <img src="admin/<?php echo $row['image']; ?>" class="card-img-top" alt="..."
                            style="height:140px !important; width:252px !important; paddding:50px; !important;">
                        <div class="card-body text-center">
                            <h5 class="card-title text-danger"><?php echo $row['foodname']; ?></h5>
                            <h6 class="card-subtitle mb-2 text-muted "><b style="font-size:20px;"><i
                                        class="fa fa-inr"></i> <?php echo $row['price']; ?>/-</b></h6>
                            <a class="btn btn-success" href=""><i class="fa fa-whatsapp"></i> Order Now</a>
                        </div>
                    </div>
                </div>
                <?php } ?>
            </div>
            </div>
            <!--<iframe width="560" height="315" src="https://www.youtube.com/embed/Yy7fVc5ZZ_U?si=Unai9oeIPTjhui4o" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>-->
        </div>
    </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script>
    $(document).ready(function() {
        $('#showpass').click(function() {
            var x = $("#password").attr("type");
            if (x === "password") {
                $("#password").attr("type", "text");
                $(".slash").php("<i class='fa fa-eye-slash'></i>");
            } else {
                $("#password").attr("type", "password");
                $(".slash").php("<i class='fa fa-eye'></i>");
            }
        });
    })
    </script>
    <?php include("footer.php") ?>