<?php include("navbar.php") ?>
    <div class="offcanvas offcanvas-end" tabindex="-1" id="sign-in" aria-labelledby="offcanvasExampleLabel">
        <div class="offcanvas-header">
            <h5 class="offcanvas-title text-primary">Sign-in</h5>
            <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>
        <div class="offcanvas-body">
            <div class="col-md-12 col-sm-12 p-5">
                <h2 class="text-center text-danger">Register Here</h2>
                <hr>
                <form action="" method="post" onsubmit="return validation();">
                    <div class="row mb-3">
                        <div class="col-3">
                            <label for="">Name</label>
                        </div>
                        <div class="col-9"><input type="text" name="fname" id="fname" class="form-control"
                                placeholder="Enter Name"></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-3">
                            <label for="">Email</label>
                        </div>
                        <div class="col-9"><input type="email" name="femail" id="femail" class="form-control"
                                placeholder="Enter Email"></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-3">
                            <label for="">Mobile</label>
                        </div>
                        <div class="col-9"><input type="tel" name="fmobile" id="fmobile" class="form-control"
                                placeholder="Enter Mobile No"></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-3">
                            <label for="">Subject</label>
                        </div>
                        <div class="col-9"><input type="text" name="fsubject" id="fsubject" class="form-control"
                                placeholder="Enter Subject"></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-3">
                            <label for="">Message</label>
                        </div>
                        <div class="col-9">
                            <textarea name="fmessage" id="fmessage" rows="4" placeholder="Enter Message"
                                class="form-control"></textarea>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12 text-center">
                            <button type="submit" class="btn btn-outline-primary btn-lg">Save</button>
                            <button type="reset" class="btn btn-outline-warning btn-lg">Reset</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-indicators">
            <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active"
                aria-current="true" aria-label="Slide 1"></button>
            <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1"
                aria-label="Slide 2"></button>
            <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2"
                aria-label="Slide 3"></button>
                <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="3"
                aria-label="Slide 4"></button>
        </div>
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="img/zomato3.jpg" class="d-block w-100" style="height: 500px;opacity: 0.8;" alt="img/slider1.webp">
                <div class="carousel-caption d-none d-md-block">
                    <h1 class="p-5"
                        style="align-items: center; font-weight: bolder; color: white; font-style: italic; font-size: 130px; font-family: 'Times New Roman';">
                        Zomato</h1>
                    <h5>Search Food Here</h5>
                    <p><input class="form-control" id="disabledInput" type="text" placeholder="Search Food Here.."></p>
                </div>
            </div>
            <div class="carousel-item">
                <img src="img/pizza.jfif" class="d-block w-100" style="height: 500px; opacity: 0.8" alt="img/slider1.webp">
                <div class="carousel-caption d-none d-md-block">
                    <h1 class="p-5"
                        style="align-items: center; font-weight: bolder; color: white; font-style: italic; font-size: 130px; font-family: 'Times New Roman';">
                        Zomato</h1>
                    <h5>Search Food Here</h5>
                    <div class="input-group slash1">
                    <input class="form-control" id="disabledInput" type="text" placeholder="Search Food Here..">
                    <i class="fa fa-search " aria-hidden="true"></i>
                </div>
                </div>
            </div>
            <div class="carousel-item">
                <img src="img/zomato4.webp" class="d-block w-100" style="height: 500px; opacity: 0.8"
                    alt="img/slider1.webp">
                <div class="carousel-caption d-none d-md-block">
                    <h1 class="p-5"
                        style="align-items: center; font-weight: bolder; color: white; font-style: italic; font-size: 130px; font-family: 'Times New Roman';">
                        Zomato</h1>
                    <h5>Search Food Here</h5>
                    <p><input class="form-control" id="disabledInput" type="text" placeholder="Search Food Here.."></p>
                </div>
            </div>
            <div class="carousel-item">
                <img src="img/zomato5.jpg" class="d-block w-100" style="height: 500px; opacity: 0.8" alt="img/slider1.webp">
                <div class="carousel-caption d-none d-md-block">
                    <h1 class="p-5"
                        style="align-items: center; font-weight: bolder; color: white; font-style: italic; font-size: 130px; font-family: 'Times New Roman';">
                        Zomato</h1>
                    <h5>Search Food Here</h5>
                    <p><input class="form-control" id="disabledInput" type="text" placeholder="Search Food Here.."></p>
                </div>
            </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions"
            data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions"
            data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
    </div>
    <div class="container-fluid p-5" style="background-color: rgb(253, 247, 240);">
        <h1 class="text-center text-danger" style="font-weight: 900; font-family: 'Times New Roman';"><i
                class="fa-fa-phone"></i>Our Speciality<i class="fa-fa-star"></i></h1>
        <hr>
        <div class="row">
        <?php 
            $select="select * from speciallity order by idproduct asc limit 6";
            $res=mysqli_query($con,$select);
            while($row=mysqli_fetch_assoc($res)){
            ?>
            <div class="col-md-2 col-sm-6 mb-sm-3">
                <div class="card">
                    <img src="admin/<?php echo $row['productimage']; ?>" class="card-img-top img-fluid" alt="..." style="height:160px !important; width:100% !important;">
                    <div class="card-body text-center">
                        <h5 class="card-title text-danger"><?php echo $row['productname']; ?></h5>
                        <h6 class="card-subtitle mb-2 text-muted "><b style="font-size:20px;"><i class="fa fa-inr"></i> <?php echo $row['mrp']; ?>/-</b></h6>
                        <h6 class="card-subtitle mb-2 text-muted "><s><i class="fa fa-inr"></i>&nbsp;<?php echo $row['salesrate']; ?>/-</s></h6>
                        <p class="card-text"><?php echo $row['productdesc']; ?></p>
                        <a class="btn btn-success" href=""><i class="fa fa-whatsapp"></i> Order Now</a>
                    </div>
                </div>
            </div>
            <?php } ?>
        </div>
    </div>
    <div class="container-fluid p-5" style="background-color: rgb(240, 243, 235);">
    <h1 class="text-center" style="font-weight: bolder; color: rgb(239, 102, 18); font-family: 'Times New Roman'; font-size: 60px;">
        About Us</h1>
        <hr>
        <div class="row">
                <?php 
                    $select="select * from aboutus aboutid ";
                    $res=mysqli_query($con,$select);
                    while($row=mysqli_fetch_assoc($res)){
                    ?>
                    <div class="col-md-6 col-sm-12">
                        <img src="admin/<?php echo $row['image']; ?>" alt="logo" class="img-fluid" style="height:500px; width:450px; margin:30px;">
                    </div>
                    <div class="col-md-6 col-sm-12">
                        <h1 class="text-center text-danger" style="font-family: 'Times New Roman'; font-weight: bolder; font-style: inherit; letter-spacing:1px;"><?php echo $row['companyname']; ?></h1>
                        <p style="text-align: justify; color: rgb(74, 8, 45);font-family: Arial; font-weight: bold;"></style=><?php echo $row['description']; ?></p>
                    </div>
                    <?php } ?>
            </div>
    </div>
    <div class="container-fluid p-5" style="background-color: rgb(251, 251, 251);">
        <h1 class="text-center"><span style="font-family: 'Times New Roman'; font-weight: bold; "> Zomato Sevices</span>
        </h1>
        <hr>
        <div class="row" style="background-color:rgb(247, 250, 252)">
        <?php 
            $select="select * from services order by serviceid desc";
            $res=mysqli_query($con,$select);
            while($row=mysqli_fetch_assoc($res)){
            ?>
            <div class="col-md-3 col-sm-6 mb-sm-3">
                <div class="card">
                    <img src="admin/<?php echo $row['simage']; ?>" class="card-img-top" alt="..." style="height:160px !important;width:272px !important;">
                    <div class="card-body text-center">
                        <h5 class="card-title text-danger"><?php echo $row['feature']; ?></h5>
                        <p class="card-text"><?php echo $row['servicedesc']; ?></p>
                    </div>
                </div>
            </div>
            <?php } ?>
        </div>
    </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script>
        $(document).ready(function(){
                 $('#showpass').click(function(){
                     var x = $("#password").attr("type");
                     if (x=== "password") {
                     $("#password").attr("type","text");
                     $(".slash").php("<i class='fa fa-eye-slash'></i>");
                     } else {
                     $("#password").attr("type","password");
                     $(".slash").php("<i class='fa fa-eye'></i>");}
                 }); })
                 </script>
<?php include("footer.php") ?>