<?php include("navbar.php") ?>
<div class="offcanvas offcanvas-end" tabindex="-1" id="sign-in" aria-labelledby="offcanvasExampleLabel">
    <div class="offcanvas-header">
        <h5 class="offcanvas-title text-primary">Sign-in</h5>
        <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
    </div>
    <div class="offcanvas-body">
        <div class="col-md-12 col-sm-12 p-5">
            <h2 class="text-center text-danger">Register Here</h2>
            <hr>
            <form action="" method="post" onsubmit="return validation();">
                <div class="row mb-3">
                    <div class="col-3">
                        <label for="">Name</label>
                    </div>
                    <div class="col-9"><input type="text" name="fname" id="fname" class="form-control"
                            placeholder="Enter Name"></div>
                </div>
                <div class="row mb-3">
                    <div class="col-3">
                        <label for="">Email</label>
                    </div>
                    <div class="col-9"><input type="email" name="femail" id="femail" class="form-control"
                            placeholder="Enter Email"></div>
                </div>
                <div class="row mb-3">
                    <div class="col-3">
                        <label for="">Mobile</label>
                    </div>
                    <div class="col-9"><input type="tel" name="fmobile" id="fmobile" class="form-control"
                            placeholder="Enter Mobile No"></div>
                </div>
                <div class="row mb-3">
                    <div class="col-3">
                        <label for="">Subject</label>
                    </div>
                    <div class="col-9"><input type="text" name="fsubject" id="fsubject" class="form-control"
                            placeholder="Enter Subject"></div>
                </div>
                <div class="row mb-3">
                    <div class="col-3">
                        <label for="">Message</label>
                    </div>
                    <div class="col-9">
                        <textarea name="fmessage" id="fmessage" rows="4" placeholder="Enter Message"
                            class="form-control"></textarea>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12 text-center">
                        <button type="submit" class="btn btn-outline-primary btn-lg">Save</button>
                        <button type="reset" class="btn btn-outline-warning btn-lg">Reset</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<div class="container-fluid p-5" style="background-color: rgb(255, 255, 255);">
    <h1 class="text-center"
        style="font-weight: bolder; color: rgb(239, 102, 18); font-family: 'Times New Roman'; font-size: 60px;">
        About Us</h1>
    <hr>
    <div class="row">
                <?php 
                    $select="select * from aboutus order by aboutid asc";
                    $res=mysqli_query($con,$select);
                    while($row=mysqli_fetch_assoc($res)){
                    ?>
                    <div class="col-md-6 col-sm-12">
                        <img src="admin/<?php echo $row['image']; ?>" alt="logo" class="img-fluid" style="height:500px; width:450px; margin:30px;">
                    </div>
                    <div class="col-md-6 col-sm-12">
                        <h1 class="text-center text-danger" style="font-family: 'Times New Roman'; font-weight: bolder; font-style: inherit; letter-spacing:1px;"><?php echo $row['companyname']; ?></h1>
                        <p style="text-align: justify; color: rgb(74, 8, 45);font-family: Arial; font-weight: bold;"></style=><?php echo $row['description']; ?></p>
                    </div>
                    <?php } ?>
            </div>
</div>
<div class="container-fluid">
    <h1
        style="font-family: 'Times New Roman'; color: maroon; text-align: center; margin-top: 20px;background-color: antiquewhite;">
        Zomato Team Members</h1>
    <hr>
    <br>
    <div class="row">
        <div class="col-md-4 col-sm-6 mb-sm-3">
            <div class="card" style="width: 18rem; border: none;margin-left: 50px;">
                <img src="https://res.cloudinary.com/startup-grind/image/upload/c_fill,dpr_2.0,f_auto,g_center,h_1080,q_100,w_1080/v1/gcs/platform-data-startupgrind/events/pankaj_chaddah_zomato.jpg"
                    class="card-img-top rounded-circle" alt="...">
                <div class="card-body">
                    <h5 class="card-title text-center text-danger">Pankaj Chaddah</h5>
                    <p class="card-text text-center">Co-founder of Zomato</p>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-sm-6 mb-sm-3">
            <div class="card" style="width: 18rem; border: none;margin-left: 50px;">
                <img src="https://londonspeakerbureau.com/wp-content/uploads/2017/12/keynote-speaker-deepinder-goyal.png"
                    class="card-img-top rounded-circle" alt="...">
                <div class="card-body">
                    <h5 class="card-title text-center text-danger">Deepinder Goyal</h5>
                    <p class="card-text text-center">CEO. Co-founder</p>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-sm-6 mb-sm-3">
            <div class="card" style="width: 18rem; border: none;margin-left: 50px;">
                <img src="https://images.yourstory.com/cs/images/people/Capture-1582790724227.PNG"
                    class="card-img-top rounded-circle" alt="...">
                <div class="card-body">
                    <h5 class="card-title text-center text-danger">Gunjan Patidar</h5>
                    <p class="card-text text-center">CTO of Zomato</p>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="container-fluid" style="margin-bottom: 30px;border: 10px;">
    <img src="https://images.yourstory.com/cs/2/3fb20ae0-2dc9-11e9-af58-c17e6cc3d915/Team_Zomato_and_Team_BetterPlace_resize1551089273076.jpg"
        alt="" height="250px" width="400px" style="margin: 10px; border-image: 10px;">
    <img src="https://th.bing.com/th/id/R.410226599f873231c44b2d1af484d58d?rik=4DTwbjjUNBIIjA&riu=http%3a%2f%2fstatic.ft.lk%2fassets%2fuploads%2fimage_506832a587.jpg&ehk=wVR3ZxyKyo39Zrp65u%2fKrL8%2fNBfl7FAfgxHjRTjwC18%3d&risl=&pid=ImgRaw&r=0"
        alt="" height="250px" width="400px" style="margin: 10px;">
    <img src="https://careers.cohesity.com/wp-content/new_media/2022/08/Careers-Hero-IMG_CS-5467_RD-Team.png" alt=""
        height="250px" width="350px" style="margin: 10px;">
    <img src="https://www.iitbbs.ac.in/national-science-day-2020/gallery/DSC_8284.JPG" alt="" height="250px"
        width="350px" style="margin-left: 250px;margin-right: 80px;margin-top: 40px;">
    <img src="https://th.bing.com/th/id/R.95c9ba39ea49c69c02e1fbc54663d11e?rik=UgVvpIXRKAE3JA&riu=http%3a%2f%2funrcpd.org%2fwp-content%2fuploads%2f2018%2f08%2f43369892864_a4605669d2_k1.jpg&ehk=QXdOUCQco8uP01dTUqnT9GfWUSYvX4P1vG3Yd2UI%2fxA%3d&risl=&pid=ImgRaw&r=0"
        alt="" height="250px" width="350px" style="margin-top: 40px;">
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
$(document).ready(function() {
    $('#showpass').click(function() {
        var x = $("#password").attr("type");
        if (x === "password") {
            $("#password").attr("type", "text");
            $(".slash").php("<i class='fa fa-eye-slash'></i>");
        } else {
            $("#password").attr("type", "password");
            $(".slash").php("<i class='fa fa-eye'></i>");
        }
    });
})
</script>
<?php include("footer.php") ?>