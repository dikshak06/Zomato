<footer>
        <div class="container-fluid bg-dark p-5">
            <div class="row">
                <div class="col-md-4 col-sm-12 text-center">
                    <h5 class="text-white">Logo</h5>
                    <img src="img/zomato logo.png" style="height: 300px; width: 600px;" alt="" class="img-fluid">
                    <p class="text-white-50">We are provide all types of Food Items.</p>
                </div>
                <div class="col-md-4 col-sm-12">
                    <h5 class="text-white">Menus</h5>
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link" href="index.php"><i class="fa fa-home"></i> Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="shop.php"><i class="fa fa-shopping-cart"></i> Shop</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="services.php"><i class="fa fa-list"></i> Services</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="aboutus.php"><i class="fa fa-user"></i> About Us</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="contactus.php"><i class="fa fa-phone"></i> Contact Us</a>
                        </li>
                        <li class="nav-item">
                        <a class="nav-link" href="admin/index.php"><i class="fa fa-lock"></i> AdminLogin</a>
                    </li>
                    </ul>
                </div>
                <div class="col-md-4 col-sm-12">
                    <h5 class="text-white">Contact Details</h5>
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link" href="tel:8552945385"><i class="fa fa-phone"></i> +91 8552945385</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="malito:smarttech@gmail.com"><i class="fa fa-envelope"></i>
                                dikshakulkarni88@gmail.com</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#"><i class="fa fa-home"></i> Address : Gokuldham complex
                                Ground floor, MG Road, Pune, Dist-Ambegoan, Pune 410503</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#"><i class="fa fa-file"></i> GSTIN : 27AEPFS3719B1ZX</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#"><i class="fa fa-address-card"></i> PAN : AEPFS3719B</a>
                        </li>
                    </ul>
                    <ul class="d-inline-flex">
                        <li><a class="nav-link" href=""><i class="fa fa-whatsapp fa-2x"></i></a></li>
                        <li><a class="nav-link" href="https://www.whatsapp.com/"><i class="fa fa-facebook fa-2x"></i></a></li>
                        <li><a class="nav-link" href="https://www.twitter.com/"><i class="fa fa-twitter fa-2x"></i></a></li>
                        <li><a class="nav-link" href="https://www.instagram.com/"><i class="fa fa-instagram fa-2x"></i></a></li>
                        <li><a class="nav-link" href="https://www.linkedin.com/"><i class="fa fa-linkedin fa-2x"></i></a></li>
                        <li><a class="nav-link" href="https://www.youtube.com/"><i class="fa fa-youtube fa-2x"></i></a></li>
                    </ul>
                </div>
            </div>
            <hr class="bg-white">
            <p class="text-center text-white mt-3"><i class="fa fa-globe"></i> Developed By Diksha Kulkarni</p>
        </div>
    </footer>
</body>
</html>
