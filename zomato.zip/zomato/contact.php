<?php include("navbar.php") ?>
<div class="offcanvas offcanvas-end" tabindex="-1" id="sign-in" aria-labelledby="offcanvasExampleLabel">
    <div class="offcanvas-header">
        <h5 class="offcanvas-title text-primary">Sign-in</h5>
        <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
    </div>

</div>
<div class="container-fluid p-5" style="background-color: rgb(222, 233, 243);">
    <h1 class="text-center" style="font-family: 'Times New Roman'; font-size: 50px; color: blue;">Contact Us <br><span
            style="color: black;">
            <h6>mobile no. 8552945385</h6>
        </span></h1>
    <hr>
    <div class="row">
        <div class="col-md-6 col-sm-12 text-center mt-5">
           
            <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1930336.7005939626!2d70.86422228276517!3d19.099368600000002!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be7c9286a1220b3%3A0xf53c9a459a124084!2sZomato%20office!5e0!3m2!1sen!2sin!4v1703270143135!5m2!1sen!2sin"
                width="500" height="450" style="border:0; margin-right:50px;" allowfullscreen="" loading="lazy"
                referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>

        <div class="col-md-6 col-sm-12 p-5 shadow">
            <h2 class="text-center"
                style="font-weight: bolder; font-family: 'Times New Roman'; color: brown; font-size:40px;">Order Something Tasty
            </h2>
            <hr>
            <form action="save.php" method="post" onsubmit="return validation();">
                <div class="row mb-3">
                    <div class="col-12 col-sm-12">
                        <div class="form-floating mt-2 mb-2">
                            <input type="text" class="form-control" id="fname" placeholder="Enter Full Name"
                                name="fname">
                            <label for="fname"> Enter Full Name</label>
                        </div>
                    </div>

                    <div class="col-12 col-sm-12">
                        <div class="form-floating mt-2 mb-2">
                            <input type="email" class="form-control" id="femail" placeholder="Enter email"
                                name="femail">
                            <label for="femail"> Enter Email Address</label>
                        </div>
                    </div>
                    <div class="col-12 col-sm-12">
                        <div class="form-floating mt-2 mb-2">
                            <input type="tel" class="form-control" id="fmobile" placeholder="Enter Mobile No"
                                name="fmobile">
                            <label for="fmobile"> Enter Mobile No</label>
                        </div>
                    </div>
                    
                    <div class="col-12 col-sm-12">
                        <select class="form-select " idaria-label="Default select example" id="fmessage"
                            name="fmessage">
                            <option selected>Order Something</option>
                            <option value="Pizza">Pizza</option>
                            <option value="Burger">Burger</option>
                            <option value="French-frice">French-frice</option>
                            <option value="Chinese Noodles4">Chinese Noodles</option>
                            <option value="Momos">Momos</option>
                            <option value="Mocktails">Mocktails</option>
                            <option value=""><a href="shop.php">Go to shop for order different</a></option>
                        </select>
                    </div>
                </div>
                <div class="col-12 col-sm-12">
                    <div class="form-floating mt-2 mb-2">
                        <textarea class="form-control rows=4" id="freview" style="height: 100px" placeholder="review"
                            name="freview"></textarea>
                        <label for="freview"> Address</label>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12 text-center">
                        <button type="submit" class="btn btn-outline-primary btn-lg mx-3" name="datasave">Save</button>
                        <button type="reset" class="btn btn-outline-warning btn-lg mx-3" name="datareset">Reset</button>
                        <button type="button" class="btn btn-outline-success btn-lg mx-3" data-bs-toggle="modal"
                            data-bs-target="#pay">
                            Pay
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<div class="modal fade modal-lg" id="pay" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content" style="background-color:black;">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="exampleModalLabel" style="border-style:solid; text-align:center; padding:5px 200px 5px 140px; border-color:green; color: white;  background-color: green; border-radius: 25px;">Pay Here</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <ol style="display:inline-flex; list-style-type:none;">
                    <li style="margin:10px;"><i class="fa fa-phonepe" ></i><button type="button" class="btn btn-outline-primary">phone pe</button></li>
                    <li style="margin:10px;"><i class="fa-brands fa-google-pay"></i><button type="button" class="btn btn-outline-success">G-pay</button></li>
                    <li style="margin:10px;"><i class="fa-brands fa-amazon-pay"></i><button type="button" class="btn btn-outline-warning">Amazon-pay</button></li>
                </ol>
            </div>
        </div>
    </div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
$(document).ready(function() {
    $('#showpass').click(function() {
        var x = $("#password").attr("type");
        if (x === "password") {
            $("#password").attr("type", "text");
            $(".slash").php("<i class='fa fa-eye-slash'></i>");
        } else {
            $("#password").attr("type", "password");
            $(".slash").php("<i class='fa fa-eye'></i>");
        }
    });
})
</script>
<script>
function validation() {
    var fname = document.getElementById('fname').value;
    var femail = document.getElementById('femail').value;
    var fmobile = document.getElementById('fmobile').value;
    var fmessage = document.getElementById('fmessage').value;
    var freview = document.getElementById('freview').value;

    var pwd_expression = /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-])/;

    var letters_expression = /^[A-Za-z]+$/;

    var number_expression = /^[0-9]+$/;

    var email_expression = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;

    if (!letters_expression.test(fname) && fname.trim() != "") {

        alert('Name field required only alphabet characters');

        $("#fname").val("");

        $("#fname").focus();

        return false;
    } else if (!email_expression.test(femail) && femail.trim() != "") {

        alert('Invalid email');

        $("#femail").val("");

        $("#femail").focus();

        return false;

    }
    if (fmobile.trim() == '') {
        alert('Please Enter Your Mobile No');
        document.getElementById('fmobile').value = "";
        document.getElementById('fmobile').focus();
        return false;
    }
    if (fmessage.trim() == '') {
        alert('Please Enter Your Subject');
        document.getElementById('fmessage').value = "";
        document.getElementById('fmessage').focus();
        return false;
    }
    if (freview.trim() == '') {
        alert('Please Enter Your Message');
        document.getElementById('freview').value = "";
        document.getElementById('freview').focus();
        return false;
    }
    return true;
}
</script>

<?php include("footer.php") ?>