<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@500&display=swap" rel="stylesheet">
    <script src="https://kit.fontawesome.com/yourcode.js" crossorigin="anonymous"></script>

</head>

<body class="bg-primary">
    <form action="" method="post" onsubmit="return registration()">
        <div class="container bg-white mt-5 mb-5">
            <h1 class="text-center text-danger">
                Register
            </h1>
            <hr>
            <div class="row">
                <div class="col-md-6">
                    <img src="register1.avif" class="img-fluid" alt="loading">
                </div>
                <div class="col-md-6">
                     <div class="col-12 col-md-12">
                            <div class="form-floating mt-3 mb-3">
                                <input type="text" class="form-control required" id="fname" placeholder="Enter Username"
                                    name="fname">
                                <label for="fname"> Enter Username</label>
                            </div>
                        </div>
                    
                    <div class="col-12 col-sm-12">
                        <div class="form-floating mt-3 mb-3">
                            <input type="email" class="form-control required" id="email" placeholder="Enter email" name="email">
                            <label for="email"> Enter Email</label>
                        </div>
                    </div>
                    
                        <div class="input-group mb-3">
                            <span for="password" class="input-group-text bg-warning text-white slash" id="showpass"><i class="fa fa-eye"></i></span>
                            <input type="password" class="form-control" name="password" id="password" placeholder="enter password">
                        </div>
                   
                     <div class="input-group mb-3">
                            <span for="password" class="input-group-text bg-warning text-white slash1" id="showpass1"><i class="fa fa-eye"></i></span>
                            <input type="password" class="form-control" name="cpassword" id="cpassword" placeholder="confirm your password">
                        </div>
               
                    <div class="col-12 col-sm-12">
                        <div class="form-check mb-3">
                            <label class="form-check-label">
                                <input class="form-check-input" type="checkbox" name="remember"> Remember me
                            </label>
                        </div>

                        <button type="button" class="btn btn-primary" id="register">Register</button>
                        <button type="reset" class="btn btn-success">Reset</button>
                        <br>
    </form>

    </div>
    <br>
    </div>
    </div>
    </div>
    </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <script>
       $(document).ready(function(){
                $('#showpass').click(function(){
                    var x = $("#password").attr("type");
	                if (x=== "password") {
		            $("#password").attr("type","text");
                    $(".slash").php("<i class='fa fa-eye-slash'></i>");
	                } else {
		            $("#password").attr("type","password");
                    $(".slash").php("<i class='fa fa-eye'></i>");}
                });
                    $('#showpass1').click(function(){
                    var x = $("#cpassword").attr("type");
	                if (x=== "password") {
		            $("#cpassword").attr("type","text");
                    $(".slash1").php("<i class='fa fa-eye-slash'></i>");
	                } else {
		            $("#cpassword").attr("type","password");
                    $(".slash1").php("<i class='fa fa-eye'></i>");
	                }


                });
                
            });
       

        $(document).ready(function () {

            $("#register").click(function () {
                let fname = $("#fname").val();

                let email = $("#email").val();

                let password = $("#password").val();

                let cpassword = $("#cpassword").val();


                var pwd_expression = /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-])/;

                var letters_expression = /^[A-Za-z]+$/;

                var number_expression = /^[0-9]+$/;

                var email_expression = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
                //blank validation start
                var returndata="";
                $('.required').each(function(){
                    // alert($(this).attr('id'));
                     if($(this).val().trim()==""){
                        alert('Please '+$(this).attr('placeholder'));
                        $(this).focus(); returndata=1;
                        return false;
                    }
                });
                if(returndata==1){
                    return false;
                }
                //blank validation End
                if (!letters_expression.test(fname) && fname.trim()!="") {

                    alert('Name field required only alphabet characters');

                    $("#fname").val("");

                    $("#fname").focus();

                    return false;

                }else if (!email_expression.test(email) && email.trim()!="") {

                    alert('Invalid email');

                    $("#email").val("");

                    $("#email").focus();

                    return false;

                } else if (!pwd_expression.test(password) && password.trim()!="") {

                    alert('Upper case, Lower case, Special character and Numeric letter are required in Password filed');

                    $("#password").val("");

                    $("#password").focus();

                    return false;

                } else if (password.trim() != cpassword.trim() && password.trim()!="" && cpassword.trim()!="") {

                    alert("Password =" + password + " & Confirm Password=" + cpassword + " Not Match..");

                    $("#password").val("");

                    $("#cpassword").val("");

                    $("#password").focus();

                    return false;

                } else {

                    alert('Thank You for Register');

                    // Redirecting to other page or website code.  

                    //window.location = "https://www.smarttechsoft.in";  

                    window.open("http://www.google.co.in/");

                    return true;

                }

            });



        });

    </script>
</body>

</html>