<?php include("navbar.php") ?>
    <div class="offcanvas offcanvas-end" tabindex="-1" id="sign-in" aria-labelledby="offcanvasExampleLabel">
        <div class="offcanvas-header">
            <h5 class="offcanvas-title text-primary">Sign-in</h5>
            <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>
        <div class="offcanvas-body">
            <div class="col-md-12 col-sm-12 p-5">
                <h2 class="text-center text-danger">Register Here</h2>
                <hr>
                <form action="" method="post" onsubmit="return validation();">
                    <div class="row mb-3">
                        <div class="col-3">
                            <label for="">Name</label>
                        </div>
                        <div class="col-9"><input type="text" name="fname" id="fname" class="form-control"
                                placeholder="Enter Name"></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-3">
                            <label for="">Email</label>
                        </div>
                        <div class="col-9"><input type="email" name="femail" id="femail" class="form-control"
                                placeholder="Enter Email"></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-3">
                            <label for="">Mobile</label>
                        </div>
                        <div class="col-9"><input type="tel" name="fmobile" id="fmobile" class="form-control"
                                placeholder="Enter Mobile No"></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-3">
                            <label for="">Subject</label>
                        </div>
                        <div class="col-9"><input type="text" name="fsubject" id="fsubject" class="form-control"
                                placeholder="Enter Subject"></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-3">
                            <label for="">Message</label>
                        </div>
                        <div class="col-9">
                            <textarea name="fmessage" id="fmessage" rows="4" placeholder="Enter Message"
                                class="form-control"></textarea>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12 text-center">
                            <button type="submit" class="btn btn-outline-primary btn-lg">Save</button>
                            <button type="reset" class="btn btn-outline-warning btn-lg">Reset</button>
                        </div>
                    </div>
                </form>
            </div>
            
        </div>
    </div>
    <div class="container-fluid p-5" style="background-color: rgb(251, 251, 251);">
        <h1 class="text-center"> <span style="font-family: 'Times New Roman';  color: maroon; "> Zomato Services</span>
        </h1>
        <hr>
        <div class="row">
        <?php 
            $select="select * from services order by serviceid asc";
            $res=mysqli_query($con,$select);
            while($row=mysqli_fetch_assoc($res)){
            ?>
            <div class="col-md-3 col-sm-6 mb-sm-3">
                <div class="card">
                    <img src="admin/<?php echo $row['simage']; ?>" class="card-img-top" alt="..." style="height:160px !important;width:272px !important;">
                    <div class="card-body text-center">
                        <h5 class="card-title text-danger"><?php echo $row['feature']; ?></h5>
                        <p class="card-text text-secendory"><?php echo $row['servicedesc']; ?></p>
                        
                    </div>
                </div>
            </div>
            <?php } ?>
        </div>
    </div>
    <div class="container d-flex justify-content-center align-items-center min-vh-100">

        <div class="row border rounded-15px; p-3 bg-white shadow box-area">

            <div class="col-md-6 rounded-4 d-flex justify-content-center align-items-center flex-column left-box"
                style="background-image:url(img/bike\ rider.jpg);">
                <div class="featured-image mb-3">
                    <img src="img/card8.jpg" class="img-fluid" style="width: 250px;">
                </div>
                <p class="text-white fs-2" style="font-family: 'Times New Roman'; font-weight:bolder;">Become a ZOMATO
                    Rider</p>
                <small class="text-white text-wrap text-center"
                    style="width: 17rem;font-family: 'Courier New', Courier, monospace;">To Become a ZOMATO Rider Please
                    Fill This Form Carefully</small>
            </div>


            <div class="col-md-6 right-box">
                <form action="" method="post" onsubmit="return registration()">
                    <div class="row align-items-center">
                        <div class="header-text mb-4">

                            <h2 class="text-danger text-center">Register Here</h2>
                            <p class="text-success text-center">RIDE WITH PRIDE.</p>
                        </div>

                        <div class="input-group mb-3">
                            <input type="text" class="form-control form-control-lg bg-light fs-6"
                                placeholder="Email Full Name" name="fname" id="fname">
                        </div>
                        <div class="input-group mb-3">
                            <input type="email" class="form-control form-control-lg bg-light fs-6"
                                placeholder="Email address" name="femail" id="femail">
                        </div>
                        <div class=" mb-3 mt-3">
                             <div class="input-group">
                                 <input type="password" class="form-control" placeholder="Enter password" name="fpassword" id="fpassword">
                                 <label for="" class="input-group-text"><input type="checkbox" onclick="myFunction()"></label>
                             </div>
                        </div>

                        <div class="input-group mb-5 d-flex justify-content-between">
                            <div class="form-check">
                                <input type="checkbox" class="form-check-input" id="formCheck">
                                <label for="formCheck" class="form-check-label text-secondary"><small>Remember
                                        Me</small></label>
                            </div>
                            <div class="forgot">
                                <small><a href="#" class="text-decoration-none">Forgot Password?</a></small>
                            </div>
                        </div>
                        <div class="input-group mb-3">
                            <button type="sumbit" name="login" class="btn btn-lg btn-primary w-100 fs-6 " >Login</button>
                        </div>

                        <div class="row">
                            <small>Click here to register<a href="#" class="text-decoration-none">Sign Up</a></small>
                        </div>

                    </div>
                </form>
            </div>
        </div>
    </div>

    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script>
        $(document).ready(function(){
                 $('#showpass').click(function(){
                     var x = $("#password").attr("type");
                     if (x=== "password") {
                     $("#password").attr("type","text");
                     $(".slash").php("<i class='fa fa-eye-slash'></i>");
                     } else {
                     $("#password").attr("type","password");
                     $(".slash").php("<i class='fa fa-eye'></i>");}
                 }); })
                 </script>
    <script>
        function myFunction() {
            var x = document.getElementById("fpassword");
            if (x.type === "password") {
                x.type = "text";
            } else {
                x.type = "password";
            }
        }
    </script>
    <script>

        function registration() {
            // alert('hi');

            var fname = document.getElementById("fname").value;
            // alert('fname = '+fname);
            var femail = document.getElementById("femail").value;



            var fpassword = document.getElementById("fpassword").value;





            // //email id expression code 

            var pwd_expression = /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-])/;

            var letters_expression = /^[A-Za-z]+$/;



            var email_expression = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;



            if (fname == '') {

                alert('Please enter your name');

                document.getElementById("fname").focus();

                return false;

            } else if (!letters_expression.test(fname)) {

                alert('Name field required only alphabet characters');

                document.getElementById("fname").value = "";

                document.getElementById("fname").focus();

                return false;

            } else if (femail == '') {

                alert('Please enter your user email id');

                document.getElementById("femail").focus();

                return false;

            } else if (!email_expression.test(femail)) {

                alert('Invalid email');

                document.getElementById("femail").value = "";

                document.getElementById("femail").focus();

                return false;

            } else if (fpassword == '') {

                alert('Please enter Password');

                document.getElementById("fpassword").focus();

                return false;

            } else if (!pwd_expression.test(fpassword)) {

                alert('Upper case, Lower case, Special character and Numeric letter are required in Password filed');

                document.getElementById("fpassword").focus();

                return false;

            } else if (document.getElementById("fpassword").value.length < 6) {

                alert('Password minimum length is 6');

                document.getElementById("fpassword").focus();

                return false;

            } else if (document.getElementById("fpassword").value.length > 12) {

                alert('Password max length is 12');

                document.getElementById("fpassword").focus();

                return false;

            } else {

                alert('Registration Successfully.');

                window.location = "https://www.smarttechsoft.in";

            }

        }

    </script>
    <?php include("footer.php") ?>