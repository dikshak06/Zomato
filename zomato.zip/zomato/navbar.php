<?php include_once('connection.php') ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>zomato</title>
    <link rel="shortcut icon" href="img/zomato1.avif" type="image/x-icon">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@500&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
    </script>
    <style>
    *:not(.fa) {
        font-family: 'poppins', sans-serif;
    }

    footer a {
        color: white !important;
    }

    ul li a {
        text-decoration: none;
        color: orange;
        font-family: Arial;
        transition: 0.4s ease-in-out;
    }

    ul li a:hover {
        color: orange;
    }

    #img {
        height: 550px;
        width: 450px;
    }

    *:not(.fa) {
        font-family: 'poppins', sans-serif;
    }

    footer a {
        color: white !important;
    }

    ul li a {
        text-decoration: none;
        color: white;
        font-family: Arial;
        transition: 0.4s ease-in-out;
    }

    ul li a:hover {
        color: rgb(213, 94, 8);
    }

    #img {
        height: 550px;
        width: 450px;
    }

    div.scroll-container {
        margin-top: 20px;
        background-color: white;
        overflow: auto;
        white-space: nowrap;
        padding: 10px;
    }

    div.scroll-container img {
        padding: 5px;
    }

    .gallery .card-wrapper {
        display: flex !important;
    }

    .gallery .card {
        margin: 0.5em !important;
        width: calc(100/4)%;
    }
    </style>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
        <div class="container-fluid px-5 py-2">
            <img src="img/zomato1.avif" alt="" height="70px" width="150px">
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="index.php"><i class="fa fa-home"></i>
                            Home</a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="shop.php"><i class="fa fa-shopping-cart"></i> Shop</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="service.php"><i class="fa fa-list"></i> Services</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="aboutus.php"><i class="fa fa-user"></i> AboutUs</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                            data-bs-toggle="dropdown" aria-expanded="false"><i class="fa fa-photo"></i>
                            Gallery
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <li><a class="dropdown-item" href="gallery.php#events"><i class="fa fa-food"></i>
                                    Events</a></li>
                            <li><a class="dropdown-item" href="gallery.php#offer"><i class="fa fa-food"></i>Offers</a>
                            </li>
                            <li>
                                <hr class="dropdown-divider">
                            </li>

                            <li><a class="dropdown-item" href="gallery.php#videos"><i class="fa fa-drink"></i>
                                    Zomato Videos</a></li>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="contact.php"><i class="fa fa-phone"></i> ContactUs</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="best restaurant.php"><i class="fa fa-phone"></i> restaurant</a>
                    </li>
                    
                </ul>
                <form class="d-flex" role="login">

                    <!-- Button trigger modal -->
                    <button type="button" class="btn btn-outline-primary mx-3" data-bs-toggle="modal"
                        data-bs-target="#login">
                        Login
                    </button>

                    <!-- Modal -->
                        <button class="btn btn-outline-warning" type="button" data-bs-toggle="offcanvas"
                        data-bs-target="#sign-in" aria-controls="offcanvasExample">
                        Sign-in
                    </button>
                </form>
            </div>
        </div>
    </nav>
    <div class="modal fade" id="login" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Login Here</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="" method="post" onsubmit="return registration()">
                        <div class="input-group mb-3">
                            <span for="text" class="input-group-text bg-primary slash1" id="showpass2"><i
                                    class="fa fa-user"></i></span>
                            <input type="text" class="form-control" name="username" id="username"
                                placeholder="enter username">
                        </div>
                        <div class="input-group mb-3">
                            <span for="password" class="input-group-text bg-primary slash" id="showpass"><i
                                    class="fa fa-eye"></i></span>
                            <input type="password" class="form-control" name="password" id="password"
                                placeholder="enter password">
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-dark" id="register">Login</button>
                </div>
            </div>
        </div>
    </div>
    
    