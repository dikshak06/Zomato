<?php
include_once("connection.php");
if(isset($_POST['datasave'])){
$fname=$_POST['fname'];
$femail=$_POST['femail'];
$fmobile=$_POST['fmobile'];
$fmessage=$_POST['fmessage'];
$freview=$_POST['freview'];
echo "<br>fname= ".$fname;
echo "<br>femail= ".$femail;
echo "<br>fmobile= ".$fmobile;
echo "<br>fmessage= ".$fmessage;
echo "<br>freview= ".$freview;
$datetime=date('Y-m-d h:i:s a');
echo "<br>sqlquery = ".$sqlquery="insert into bookingform(fname,femail,fmobile,fmessage,freview,datetime) values('".$fname."','".$femail."','".$fmobile."','".$fmessage."','".$freview."','".$datetime."')";
mysqli_query($con,$sqlquery);
header('location:contact.php');
}
    

?>