<?php include("navbar.php") ?>
    <div class="offcanvas offcanvas-end" tabindex="-1" id="sign-in" aria-labelledby="offcanvasExampleLabel">
        <div class="offcanvas-header">
            <h5 class="offcanvas-title text-primary">Sign-in</h5>
            <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>
        <div class="offcanvas-body">
            <div class="col-md-12 col-sm-12 p-5">
                <h2 class="text-center text-danger">Register Here</h2>
                <hr>
                <form action="" method="post" onsubmit="return validation();">
                    <div class="row mb-3">
                        <div class="col-3">
                            <label for="">Name</label>
                        </div>
                        <div class="col-9"><input type="text" name="fname" id="fname" class="form-control"
                                placeholder="Enter Name"></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-3">
                            <label for="">Email</label>
                        </div>
                        <div class="col-9"><input type="email" name="femail" id="femail" class="form-control"
                                placeholder="Enter Email"></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-3">
                            <label for="">Mobile</label>
                        </div>
                        <div class="col-9"><input type="tel" name="fmobile" id="fmobile" class="form-control"
                                placeholder="Enter Mobile No"></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-3">
                            <label for="">Subject</label>
                        </div>
                        <div class="col-9"><input type="text" name="fsubject" id="fsubject" class="form-control"
                                placeholder="Enter Subject"></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-3">
                            <label for="">Message</label>
                        </div>
                        <div class="col-9">
                            <textarea name="fmessage" id="fmessage" rows="4" placeholder="Enter Message"
                                class="form-control"></textarea>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12 text-center">
                            <button type="submit" class="btn btn-outline-primary btn-lg">Save</button>
                            <button type="reset" class="btn btn-outline-warning btn-lg">Reset</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <section class="grid text-white"
        style="background-image: url(https://i.ytimg.com/vi/uRR2xqXytGA/maxresdefault.jpg); opacity: 0.8; background-repeat: no-repeat;background-size: cover;" id="events">
        <div class="content p-5"
            style="display: grid; grid-template-columns: 50% auto;gap: 30px; align-items: center; justify-content:space-between; width: 100%;">
            <div class="content-left">
                <div class="info" style="max-width: 100%; display: flex; flex-direction: column;">
                    <h2
                        style="font-size: 60px;font-family: sans-serif;margin-bottom: 30px;color:rgb(250, 249, 255);font-weight: bolder;">
                        Life is a party!</h2>
                    <h4>and we will help you book the best</h4>
                    <p
                        style="font-size: 23px;line-height: 2pc;font-family: sans-serif;margin-bottom: 30px;color: rgb(246, 242, 242);">
                        Hey Our
                        checkout the most exclusive New year parties around you</p>
                </div>
                <button
                    style="padding: 10px 23px ; background-color: rgb(247, 243, 242);color: White; border: none; border-radius: 10px;margin-bottom: 15px; color: black;">Explore
                    Now</button>
                    <br>
                    <br>
            </div>
            <div class="content-right">
            </div>
        </div>
    </section>
    <div class="scroll-container">
    <?php 
        $select="select * from gallery where category='image'";
        $res=mysqli_query($con,$select);
        while($row=mysqli_fetch_assoc($res)){
        ?>
            <img src="admin/<?php echo $row['image']; ?>" alt="Cinque Terre" width="340" height="250" >
        <?php } ?>
    </div>
    <section class="grid text-white"
        style="background-color:rgb(254, 235, 235); opacity: 0.7; background-repeat: no-repeat;background-size: cover;" id="offer">
        <div class="content p-5"
            style="display: grid; grid-template-columns: 50% auto;gap: 30px; align-items: center; justify-content:space-between; width: 100%;">
            <div class="content-left">
                <div class="info" style="max-width: 100%; display: flex; flex-direction: column;">
                    <h2
                        style="font-size: 60px;font-family: sans-serif;margin-bottom: 30px;color:maroon;font-weight: bolder;">
                        Special offers</h2>
                    <p style="font-size: 23px;line-height: 2pc;font-family: sans-serif;margin-bottom: 30px;color: red;">
                        Hey Our
                        delicious food is waiting for you,<br>We are always near to you with fresh item of food</p>
                </div>
                <button
                    style="padding: 10px 23px ; background-color: rgb(255, 85, 0);color: White; border: none; border-radius: 10px;margin-bottom: 15px;">Explore
                    Food</button>
            </div>
            <div class="content-right">
            </div>
        </div>
    </section>
    <div class="container-fluid p-5 gallery">
        <h1 style="color: maroon; font-family: 'Times New Roman';">Todays Special Offers</h1>
        <div id="carouselExample" class="carousel slide">
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <div class="card-wrapper">
                    <?php 
                        $select="select * from speciallity order by idproduct asc limit 4";
                        $res=mysqli_query($con,$select);
                        while($row=mysqli_fetch_assoc($res)){
                        ?>
                        <div class="card" style="border: none;">
                            <img src="admin/<?php echo $row['productimage']; ?>" class="card-img-top rounded-circle" alt="..."
                                style="height: 200px;width: 100%;">
                            <div class="card-body text-center">
                                <h5 class="card-title"><?php echo $row['productname']; ?></h5>
                                <h6 class="card-subtitle mb-2 text-muted "><s><i class="fa fa-inr"></i> <?php echo $row['mrp']; ?>/-</s></h6>
                                <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr"></i> <?php echo $row['salesrate']; ?>/-</h6>
                                <a class="btn btn-success" href="https://api.whatsapp.com/send?phone=918552945385&amp;text=Hi, I am contacting you through your website."><i class="fa fa-whatsapp"></i> Buy Now</a>
                            </div>
                        </div>
                        <?php } ?>
                        <!-- <div class="card" style="border: none;">
                            <img src="img/bar1.jfif" class="card-img-top rounded-circle" alt="..."
                                style="height: 200px;width: 100%;">
                            <div class="card-body text-center">
                                <h5 class="card-title">Salad</h5>
                                <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr"></i> 100/-</h6>
                                <a class="btn btn-success" href=""><i class="fa fa-whatsapp"></i> Order Now</a>
                            </div>
                        </div>
                        <div class="card" style="border: none;">
                            <img src="img/bar2.jfif" class="card-img-top rounded-circle" alt="..."
                                style="height: 200px;width: 100%;">
                            <div class="card-body text-center">
                                <h5 class="card-title">Cutlet</h5>
                                <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr"></i> 89/-</h6>
                                <a class="btn btn-success" href=""><i class="fa fa-whatsapp"></i> Order Now</a>
                            </div>
                        </div>
                        <div class="card" style="border: none;">
                            <img src="img/bar3.jfif" class="card-img-top rounded-circle" alt="..."
                                style="height: 200px;width: 100%;">
                            <div class="card-body text-center">
                                <h5 class="card-title">Barbeque</h5>
                                <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr"></i> 110-</h6>
                                <a class="btn btn-success" href=""><i class="fa fa-whatsapp"></i> Order Now</a>
                            </div>
                        </div> -->
                    </div>
                </div>
                <div class="carousel-item">
                    <div class="card-wrapper">
                    <?php 
                        $select="select * from speciallity order by idproduct asc limit 4 offset 4";
                        $res=mysqli_query($con,$select);
                        while($row=mysqli_fetch_assoc($res)){
                        ?>
                        <div class="card" style="border: none;">
                            <img src="admin/<?php echo $row['productimage']; ?>" class="card-img-top rounded-circle" alt="..."
                                style="height: 200px;width: 100%;">
                            <div class="card-body text-center">
                                <h5 class="card-title"><?php echo $row['productname']; ?></h5>
                                <h6 class="card-subtitle mb-2 text-muted "><s><i class="fa fa-inr"></i> <?php echo $row['mrp']; ?>/-</s></h6>
                                <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr"></i> <?php echo $row['salesrate']; ?>/-</h6>
                                <a class="btn btn-success" href="https://api.whatsapp.com/send?phone=918552945385&amp;text=Hi, I am contacting you through your website."><i class="fa fa-whatsapp"></i> Buy Now</a>
                            </div>
                        </div>
                        <?php } ?>
                        <!-- <div class="card" style="border: none;">
                            <img src="img/bar4.jfif" class="card-img-top rounded-circle" alt="..."
                                style="height: 200px;width: 100%;">
                            <div class="card-body text-center">
                                <h5 class="card-title">Smoke Drinks</h5>
                                <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr"></i> 99/-</h6>
                                <a class="btn btn-success" href=""><i class="fa fa-whatsapp"></i> Order Now</a>
                            </div>
                        </div>
                        <div class="card" style="border: none;">
                            <img src="img/bar5.jpg" class="card-img-top rounded-circle" alt="..."
                                style="height: 200px;width: 100%;">
                            <div class="card-body text-center">
                                <h5 class="card-title">Mocktails</h5>
                                <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr"></i> 79/-</h6>
                                <a class="btn btn-success" href=""><i class="fa fa-whatsapp"></i> Order Now</a>
                            </div>
                        </div>
                        <div class="card" style="border: none;">
                            <img src="img/bar6.webp" class="card-img-top rounded-circle" alt="..."
                                style="height: 200px;width: 100%;">
                            <div class="card-body text-center">
                                <h5 class="card-title">Paneer Tikka</h5>
                                <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr"></i> 120/-</h6>
                                <a class="btn btn-success" href=""><i class="fa fa-whatsapp"></i> Order Now</a>
                            </div>
                        </div>
                        <div class="card" style="border: none;">
                            <img src="img/bar7.jpg" class="card-img-top rounded-circle" alt="..."
                                style="height: 200px;width: 100%;">
                            <div class="card-body text-center">
                                <h5 class="card-title">Panipuri</h5>
                                <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr"></i> 69/-</h6>
                                <a class="btn btn-success" href=""><i class="fa fa-whatsapp"></i> Order Now</a>
                            </div>
                        </div> -->
                    </div>
                </div>
                <div class="carousel-item">
                    <div class="card-wrapper">
                    <?php 
                        $select="select * from speciallity order by idproduct asc limit 4 offset 8";
                        $res=mysqli_query($con,$select);
                        while($row=mysqli_fetch_assoc($res)){
                        ?>
                        <div class="card" style="border: none;">
                            <img src="admin/<?php echo $row['productimage']; ?>" class="card-img-top rounded-circle" alt="..."
                                style="height: 200px;width: 100%;">
                            <div class="card-body text-center">
                                <h5 class="card-title"><?php echo $row['productname']; ?></h5>
                                <h6 class="card-subtitle mb-2 text-muted "><s><i class="fa fa-inr"></i> <?php echo $row['mrp']; ?>/-</s></h6>
                                <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr"></i> <?php echo $row['salesrate']; ?>/-</h6>
                                <a class="btn btn-success" href="https://api.whatsapp.com/send?phone=918552945385&amp;text=Hi, I am contacting you through your website."><i class="fa fa-whatsapp"></i> Buy Now</a>
                            </div>
                        </div>
                        <?php } ?>
                        <!-- <div class="card" style="border: none;">
                            <img src="img/card1.avif" class="card-img-top rounded-circle" alt="..."
                                style="height: 200px;width: 100%;">
                            <div class="card-body text-center">
                                <h5 class="card-title">Double Slice Burger</h5>
                                <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr"></i> 130/-</h6>
                                <a class="btn btn-success" href=""><i class="fa fa-whatsapp"></i> Order Now</a>
                            </div>
                        </div>
                        <div class="card" style="border: none;">
                            <img src="img/card2.webp" class="card-img-top rounded-circle" alt="..."
                                style="height: 200px;width: 100%;">
                            <div class="card-body text-center">
                                <h5 class="card-title">chiz pizza</h5>
                                <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr"></i> 150/-</h6>
                                <a class="btn btn-success" href=""><i class="fa fa-whatsapp"></i> Order Now</a>
                            </div>
                        </div>
                        <div class="card" style="border: none;">
                            <img src="img/nonveg1.jpg" class="card-img-top rounded-circle" alt="..."
                                style="height: 200px;width: 100%;">
                            <div class="card-body text-center">
                                <h5 class="card-title">Chicken Lilipop</h5>
                                <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr"></i> 140/-</h6>
                                <a class="btn btn-success" href=""><i class="fa fa-whatsapp"></i> Order Now</a>
                            </div>
                        </div>
                        <div class="card" style="border: none;">
                            <img src="img/card3.jpg" class="card-img-top rounded-circle" alt="..."
                                style="height: 200px;width: 100%;">
                            <div class="card-body text-center">
                                <h5 class="card-title">Veg Noodles With Soup</h5>
                                <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr"></i> 59,999/-</h6>
                                <a class="btn btn-success" href=""><i class="fa fa-whatsapp"></i> Order Now</a>
                            </div>
                        </div> -->
                    </div>
                </div>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>
    </div>
    <div class="container-fluid" id="videos">
        <h1 style="color: maroon; font-family: 'Times New Roman'; margin-left: 35px;">Zomato Videos</h1>
        <div class="scroll-container p-5">
        <?php 
            $select="select * from gallery where category='video'";
            $res=mysqli_query($con,$select);
            while($row=mysqli_fetch_assoc($res)){ ?>
            <iframe width="400" height="215" src="<?php echo $row['video']; ?>" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
        <?php } ?>
    </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script>
        $(document).ready(function(){
                 $('#showpass').click(function(){
                     var x = $("#password").attr("type");
                     if (x=== "password") {
                     $("#password").attr("type","text");
                     $(".slash").php("<i class='fa fa-eye-slash'></i>");
                     } else {
                     $("#password").attr("type","password");
                     $(".slash").php("<i class='fa fa-eye'></i>");}
                 }); })
                 </script>
    <?php include("footer.php") ?>