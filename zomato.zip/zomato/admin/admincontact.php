<?php include_once("adminnavbar.php") ?>
  <main class="col-md-9 ml-sm-auto col-lg-10 px-md-4">
        <div
          class="row">
          <h1 class="h2" style="font-family:times new roman; color:navy;">Contact us Data</h1>
        <div class="col-12">
          <table class="table table-bordered table-hover" style="margin-top:30px;">
            <thead>
              <tr style="text-align:center; background-color:#3c8dbc;color:white;">
                <th>Action</th>
                <th>SrNo</th>
                <th>Full Name</th>
                <th>Email-ID</th>
                <th>Mobile</th>
                <th>Order</th>
                <th>Message</th>
                <th>Date & Time</th>
              </tr>
            </thead>
            <tbody>
                <?php 
                $sqlquery="select * from bookingform";
                $res=mysqli_query($con,$sqlquery);
                $i=1;
                while($row=mysqli_fetch_assoc($res)){ ?>
                    <tr>
                      <td>
                      <form action="" method="post">
                                    <input type="hidden" name="contactid_<?php echo $row['contactid'];?>" id="contactid_<?php echo $row['contactid'];?>" value="<?php echo $row['contactid'];?>">
                                    <button type="submit" name="delete_<?php echo $row['contactid'];?>" class="btn btn-outline-danger btn-sm"><i class="fa fa-trash"></i>Delete</button>
                                  </form>
                                  <?php
                                    if(isset($_POST['delete_'.$row['contactid']])){
                                      $contactid=$_POST['contactid_'.$row['contactid']];
                                      $delsql="delete from bookingform where contactid='$contactid'";
                                      $sss=mysqli_query($con,$delsql);
                                      if($sss){
                                        echo "<script> alert('Contact us data deleted successfully.')</script>";
                                        echo "<script> window.location='admincontact.php';</script>";
                                      }
                                    }
                                  ?>
                      </td>
                        <td><?php echo $i++; ?></td>
                        <td><?php echo $row['fname']; ?></td>
                        <td><?php echo $row['femail']; ?></td>
                        <td><?php echo $row['fmobile']; ?></td>
                        <td><?php echo $row['fmessage']; ?></td>
                        <td><?php echo $row['freview']; ?></td>
                        <td><?php echo $row['datetime']; ?></td>
                     </tr>
              <?php  }
                ?>
            </tbody>
          </table>
          </div>
        </div>
      </main>
      <?php include_once("adminfooter.php") ?>