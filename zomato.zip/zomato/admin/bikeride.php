<?php include_once("adminnavbar.php") ?>
  <main class="col-md-9 ml-sm-auto col-lg-10 px-md-4">
        <div
          class="row">
          <h1 class="h2" style="font-family:times new roman; color:navy;">Contact us Data</h1>
        <div class="col-12">
          <table class="table table-bordered table-hover" style="margin-top:30px;">
            <thead>
              <tr style="text-align:center; background-color:#3c8dbc;color:white;">
                <th>Action</th>
                <th>SrNo</th>
                <th>Full Name</th>
                <th>Email-ID</th>
                <th>Address</th>
               <th>Date & Time</th>
              </tr>
            </thead>
            <tbody>
                <?php 
                $sqlquery="select * from bikeride";
                $res=mysqli_query($con,$sqlquery);
                $i=1;
                while($row=mysqli_fetch_assoc($res)){ ?>
                    <tr>
                      <td>
                      <form action="" method="post">
                                    <input type="hidden" name="id_<?php echo $row['id'];?>" id="id_<?php echo $row['id'];?>" value="<?php echo $row['id'];?>">
                                    <button type="submit" name="delete_<?php echo $row['id'];?>" class="btn btn-outline-danger btn-sm"><i class="fa fa-trash"></i>Delete</button>
                                  </form>
                                  <?php
                                    if(isset($_POST['delete_'.$row['id']])){
                                      $contactid=$_POST['id_'.$row['id']];
                                      $delsql="delete from bikeride where id='$id'";
                                      $sss=mysqli_query($con,$delsql);
                                      if($sss){
                                        echo "<script> alert('Contact us data deleted successfully.')</script>";
                                        echo "<script> window.location='bikeride.php';</script>";
                                      }
                                    }
                                  ?>
                      </td>
                        <td><?php echo $i++; ?></td>
                        <td><?php echo $row['fname']; ?></td>
                        <td><?php echo $row['femail']; ?></td>
                        
                        <td><?php echo $row['faddress']; ?></td>
                        <td><?php echo $row['datetime']; ?></td>
                     </tr>
              <?php  }
                ?>
            </tbody>
          </table>
          </div>
        </div>
      </main>
      <?php include_once("adminfooter.php") ?>