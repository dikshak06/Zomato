<?php include_once('../connection.php') ?>
<?php
    if($_SESSION['adminid']==""){
        echo "<script> alert('Something went wrong...');</script>";
        header('location:index.php');
    }
?>
<!DOCTYPE html>
<html>
<head>
	<title>Dashboard</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link href="https://cdn.datatables.net/1.13.7/css/jquery.dataTables.min.css" rel="stylesheet">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>

	<style>
    * {
	padding: 0;
	margin: 0;
	box-sizing: border-box;
	font-family: arial, sans-serif;
}
.header {
	display: flex;
	justify-content: space-between;
	align-items: center;
	padding: 15px 30px;
	background: #23242b;
	color: #fff;
}
.u-name {
	font-size: 20px;
	padding-left: 17px;
}
.u-name b {
	color: #127b8e;
}
.header i {
	font-size: 30px;
	cursor: pointer;
	color: #fff;
}
.header i:hover {
	color: #127b8e;
}
.user-p {
	text-align: center;
	padding-left: 10px;
	padding-top: 25px;
}
.user-p img {
	width: 100px;
	border-radius: 50%;
}
.user-p h4 {
	color: #ccc;
	padding: 5px 0;

}
.side-bar {
	width: 250px;
	background: royalblue;
	min-height: 100vh;
	transition: 500ms width;
}
.body {
	display: flex;
}
.section-1 {
	width: 100%;
	background: url("../img/bg.jpg");
	background-size: cover;
	background-position: center;
	display: flex;
	justify-content: center;
	align-items: center;
	flex-direction: column;
}
.section-1 h1 {
	color: #fff;
	font-size: 60px;
}
.section-1 p {
	color: #127b8e;
	font-size: 20px;
	background: #fff;
	padding: 7px;
	border-radius: 5px;
}
.side-bar ul {
	margin-top: 20px;
	list-style: none;
}
.side-bar ul li {
	font-size: 16px;
	padding: 15px 0px;
	padding-left: 20px;
	transition: 500ms background;
	white-space: nowrap;
	overflow: hidden;
	text-overflow: ellipsis;
}
.side-bar ul li:hover {
	background: white;
}
.side-bar ul li a {
	text-decoration: none;
	color: #eee;
	cursor: pointer;
	letter-spacing: 1px;
}
.side-bar ul li a i {
	display: inline-block;
	padding-right: 10px;
	font-size: 23px;
}
#navbtn {
	display: inline-block;
	margin-left: 70px;
	font-size: 20px;
	transition: 500ms color;
}
#checkbox {
	display: none;
}
#checkbox:checked ~ .body .side-bar {
	width: 60px;
}
#checkbox:checked ~ .body .side-bar .user-p{
	visibility: hidden;
}
#checkbox:checked ~ .body .side-bar a span{
	display: none;
}
  </style>
</head>
<body>
	<input type="checkbox" id="checkbox">
	<header class="header">
		<h2 class="u-name"><b class="text-danger" style="font-size:25px;">zomato</b>
			<label for="checkbox">
				<i id="navbtn" class="fa fa-bars" aria-hidden="true"></i>
			</label>
		</h2>
		<i class="fa fa-user" aria-hidden="true"></i>
	</header>
	<div class="body">
		<nav class="side-bar">
			<div class="user-p">
				<img src="zomato\img\dik.jpeg">
				<h4>Diksha</h4>
			</div>
			<ul class="nav flex-column">
            <li class="nav-item">
              <a class="nav-link" aria-current="page" href="#">
                <span data-feather="home"></span>
                <i class="fa fa-user fa-2x"></i> <?php echo $_SESSION['username'];?>
              </a>
            </li>
            <hr>
            <li class="nav-item">
              <a class="nav-link active" aria-current="page" href="dash.php"><i class="fa fa-dashboard fa-2x"></i>

                <span data-feather="home"></span>
                Dashboard
				
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="adminspeciallity.php"><i class="fa fa-cutlery fa-2x"></i>
                <span data-feather="file"></span> 
                Speciallity
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="admincontact.php"><i class="fa fa-phone fa-2x"></i>
                <span data-feather="file"></span>
                Contact Us
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="adminabout.php"><i class="fa fa-group fa-2x"></i>
                <span data-feather="file"></span>
                About Us
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="adminservice.php"><i class="fa fa-server fa-2x"></i>
                <span data-feather="file"></span>
                Services
              </a>
            </li>
			<li class="nav-item">
              <a class="nav-link" href="adminshop.php"><i class="fa fa-shopping-cart fa-2x"></i>
                <span data-feather="file"></span>
                Shop
              </a>
            </li>
			<li class="nav-item">
              <a class="nav-link" href="admingallery.php"><i class="fa fa-photo fa-2x"></i>
                <span data-feather="file"></span>
                gallery
              </a>
            </li>
          </ul>
		</nav>
		
	