<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ContactUs</title>
    <link rel="shortcut icon" href="zomato1.avif" type="image/x-icon">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@500&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
        crossorigin="anonymous"></script>
    <style>
        *:not(.fa) {
            font-family: 'poppins', sans-serif;
        }

        footer a {
            color: white !important;
        }

        ul li a {
            text-decoration: none;
            color: white;
            font-family: Arial;
            transition: 0.4s ease-in-out;
        }

        ul li a:hover {
            color: rgb(213, 94, 8);
        }

        #img {
            height: 550px;
            width: 450px;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
        <div class="container-fluid px-5 py-2">
            <img src="img/zomato1.avif" alt="" height="70px" width="150px">
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="index.php"><i class="fa fa-home"></i>
                            Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="shop.php"><i class="fa fa-shopping-cart"></i> Shop</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="service.php"><i class="fa fa-list"></i> Services</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="about us.php"><i class="fa fa-user"></i> AboutUs</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                            data-bs-toggle="dropdown" aria-expanded="false">
                            Gallery
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <li><a class="dropdown-item" href="gallery.php#events"><i class="fa fa-food"></i>
                                    Events</a></li>
                            <li><a class="dropdown-item" href="gallery.php#offer"><i class="fa fa-food"></i>Offers</a>
                            </li>
                            <li>
                                <hr class="dropdown-divider">
                            </li>
                            
                            <li><a class="dropdown-item" href="gallery.php#videos"><i class="fa fa-drink"></i>
                                    Zomato Videos</a></li>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="contactUs.php"><i class="fa fa-phone"></i> ContactUs</a>
                    </li>
                </ul>
                <form class="d-flex" role="login">

                    <!-- Button trigger modal -->
                    <button type="button" class="btn btn-outline-primary mx-3" data-bs-toggle="modal"
                        data-bs-target="#login">
                        Login
                    </button>

                    <!-- Modal -->



                    <button class="btn btn-outline-warning" type="button" data-bs-toggle="offcanvas"
                        data-bs-target="#sign-in" aria-controls="offcanvasExample">
                        Sign-in
                    </button>


                </form>

            </div>
        </div>
    </nav>
    <div class="modal fade" id="login" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Login Here</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="input-group mb-3">
                        <span for="text" class="input-group-text bg-primary text-white slash1" id="showpass2"><i class="fa fa-user"></i></span>
                        <input type="text" class="form-control" name="username" id="username" placeholder="enter username">
                    </div>
                    <div class="input-group mb-3">
                        <span for="password" class="input-group-text bg-primary text-white slash" id="showpass"><i class="fa fa-eye"></i></span>
                        <input type="password" class="form-control" name="password" id="password" placeholder="enter password">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary">Login</button>
                </div>
            </div>
        </div>
    </div>
    <div class="offcanvas offcanvas-end" tabindex="-1" id="sign-in" aria-labelledby="offcanvasExampleLabel">
        <div class="offcanvas-header">
            <h5 class="offcanvas-title text-primary">Sign-in</h5>
            <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>
        <div class="offcanvas-body">
            <div class="col-md-12 col-sm-12 p-5">
                <h2 class="text-center text-danger">Register Here</h2>
                <hr>
                <form action="" method="post" onsubmit="return validation();">
                    <div class="row mb-3">
                        <div class="col-3">
                            <label for="">Name</label>
                        </div>
                        <div class="col-9"><input type="text" name="fname" id="fname" class="form-control"
                                placeholder="Enter Name"></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-3">
                            <label for="">Email</label>
                        </div>
                        <div class="col-9"><input type="email" name="femail" id="femail" class="form-control"
                                placeholder="Enter Email"></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-3">
                            <label for="">Mobile</label>
                        </div>
                        <div class="col-9"><input type="tel" name="fmobile" id="fmobile" class="form-control"
                                placeholder="Enter Mobile No"></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-3">
                            <label for="">Subject</label>
                        </div>
                        <div class="col-9"><input type="text" name="fsubject" id="fsubject" class="form-control"
                                placeholder="Enter Subject"></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-3">
                            <label for="">Message</label>
                        </div>
                        <div class="col-9">
                            <textarea name="fmessage" id="fmessage" rows="4" placeholder="Enter Message"
                                class="form-control"></textarea>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12 text-center">
                            <button type="submit" class="btn btn-outline-primary btn-lg">Save</button>
                            <button type="reset" class="btn btn-outline-warning btn-lg">Reset</button>
                        </div>
                    </div>
                </form>
            </div>
            
        </div>
    </div>
    <div class="container-fluid p-5" style="background-color: rgb(222, 233, 243);">
        <h1 class="text-center" style="font-family: 'Times New Roman'; font-size: 50px; color: blue;">Contact Us <br><span style="color: black;"><h6>mobile no. 8552945385</h6></span></h1>
        <hr>
        <div class="row">
            <div class="col-md-6 col-sm-12 text-center mt-5">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1930336.7005939626!2d70.86422228276517!3d19.099368600000002!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be7c9286a1220b3%3A0xf53c9a459a124084!2sZomato%20office!5e0!3m2!1sen!2sin!4v1703270143135!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>
            <div class="col-md-6 col-sm-12 p-5">
                <h2 class="text-center" style="font-weight: bolder; font-family: 'Times New Roman'; color: brown; font-size:50px;">Booking Now</h2>
                <hr>
                <form action="" method="post" onsubmit="return validation();">
                    <div class="row mb-3">
                        <div class="col-12 col-sm-12">
                            <div class="form-floating mt-2 mb-2">
                                <input type="text" class="form-control" id="text" placeholder="Enter Full Name" name="text" required>
                                <label for="text"> Enter Full Name</label>
                            </div>
                        </div>
                        
                        <div class="col-12 col-sm-12">
                            <div class="form-floating mt-2 mb-2">
                                <input type="email" class="form-control" id="email" placeholder="Enter email" name="email" required>
                                <label for="email"> Enter Email Address</label>
                            </div>
                        </div>
                        <div class="col-12 col-sm-12">
                            <div class="form-floating mt-2 mb-2">
                                <input type="tel" class="form-control" id="tel" placeholder="Enter Mobile No" name="tel" required>
                                <label for="tel"> Enter Mobile No</label>
                            </div>
                        </div>
                        <div class="col-12 col-sm-12">
                            <select class="form-select" aria-label="Default select example">
                                <option selected>Order Something</option>
                                <option value="1">Pizza</option>
                                <option value="2">Burger</option>
                                <option value="3">French-frice</option>
                                <option value="4">Chinese Noodles</option>
                                <option value="5">Momos</option>
                                <option value="6">Mocktails</option>
                                <option value="6">Other</option>
                              </select>
                            </div>
                        </div>
                        <div class="col-12 col-sm-12">
                            <div class="form-floating mt-2 mb-2">
                                <textarea class="form-control rows=4" id="review" style="height: 100px" placeholder="review" name="review" required></textarea>
                                <label for="tel"> Reviews</label>
                            </div>
                        </div>
                    <div class="row">
                        <div class="col-12 text-center">
                            <button type="button" class="btn btn-outline-primary btn-lg mx-3">Save</button>
                            <button type="button" class="btn btn-outline-warning btn-lg mx-3">Reset</button>
                            <button type="button" class="btn btn-outline-success btn-lg mx-3">Pay</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <footer>
        <div class="container-fluid bg-dark p-5">
            <div class="row">
                <div class="col-md-4 col-sm-12 text-center">
                    <h5 class="text-white">Logo</h5>
                    <img src="img/zomato logo.png" style="height: 300px; width: 600px;" alt="" class="img-fluid">
                    <p class="text-white-50">We are provide all types of Food Items.</p>
                </div>
                <div class="col-md-4 col-sm-12">
                    <h5 class="text-white">Menus</h5>
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link" href="index.php"><i class="fa fa-home"></i> Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="shop.php"><i class="fa fa-shopping-cart"></i> Shop</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="services.php"><i class="fa fa-list"></i> Services</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="aboutus.php"><i class="fa fa-user"></i> About Us</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="contactus.php"><i class="fa fa-phone"></i> Contact Us</a>
                        </li>
                    </ul>
                </div>
                <div class="col-md-4 col-sm-12">
                    <h5 class="text-white">Contact Details</h5>
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link" href="tel:8552945385"><i class="fa fa-phone"></i> +91 8552945385</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="malito:smarttech@gmail.com"><i class="fa fa-envelope"></i>
                               dikshakulkarni88@gmail.com</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#"><i class="fa fa-home"></i> Address : Gokuldham complex 
                                Ground floor, MG Road, Pune, Dist-Ambegoan, Pune 410503</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#"><i class="fa fa-file"></i> GSTIN : 27AEPFS3719B1ZX</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#"><i class="fa fa-address-card"></i> PAN : AEPFS3719B</a>
                        </li>
                    </ul>
                    <ul class="d-inline-flex">
                        <li><a class="nav-link" href="#"><i class="fa fa-whatsapp fa-2x"></i></a></li>
                        <li><a class="nav-link" href="#"><i class="fa fa-facebook fa-2x"></i></a></li>
                        <li><a class="nav-link" href="#"><i class="fa fa-twitter fa-2x"></i></a></li>
                        <li><a class="nav-link" href="#"><i class="fa fa-instagram fa-2x"></i></a></li>
                        <li><a class="nav-link" href="#"><i class="fa fa-linkedin fa-2x"></i></a></li>
                        <li><a class="nav-link" href="#"><i class="fa fa-youtube fa-2x"></i></a></li>
                    </ul>
                </div>
            </div>
            <hr class="bg-white">
            <p class="text-center text-white mt-3"><i class="fa fa-globe"></i> Developed By Diksha Kulkarni</p>
        </div>
    </footer>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script>
        $(document).ready(function(){
                 $('#showpass').click(function(){
                     var x = $("#password").attr("type");
                     if (x=== "password") {
                     $("#password").attr("type","text");
                     $(".slash").php("<i class='fa fa-eye-slash'></i>");
                     } else {
                     $("#password").attr("type","password");
                     $(".slash").php("<i class='fa fa-eye'></i>");}
                 }); })
                 </script>
    <script>
        function validation() {
            var fname = document.getElementById('fname').value;
            var femail = document.getElementById('femail').value;
            var fmobile = document.getElementById('fmobile').value;
            var fsubject = document.getElementById('fsubject').value;
            var fmessage = document.getElementById('fmessage').value;

            if (fname.trim() == '') {
                alert('Please Enter Your Name');
                document.getElementById('fname').value = "";
                document.getElementById('fname').focus();
                return false;
            }
            if (femail.trim() == '') {
                alert('Please Enter Your Email Id');
                document.getElementById('femail').value = "";
                document.getElementById('femail').focus();
                return false;
            }
            if (fmobile.trim() == '') {
                alert('Please Enter Your Mobile No');
                document.getElementById('fmobile').value = "";
                document.getElementById('fmobile').focus();
                return false;
            }
            if (fsubject.trim() == '') {
                alert('Please Enter Your Subject');
                document.getElementById('fsubject').value = "";
                document.getElementById('fsubject').focus();
                return false;
            }
            if (fmessage.trim() == '') {
                alert('Please Enter Your Message');
                document.getElementById('fmessage').value = "";
                document.getElementById('fmessage').focus();
                return false;
            }
            return true;
        }
    </script>
</body>

</html>