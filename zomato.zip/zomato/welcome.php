<html> 
<body> 
Welcome <?php echo $_GET["fname"]; ?><br> 
Your email address is: <?php echo $_GET["femail"]; ?> 
Your mobile number is: <?php echo $_GET["fmobile"]; ?> 
Your selected item is: <?php echo $_GET["fmessage"]; ?> 
Your selected item is: <?php echo $_GET["freview"]; ?> 

</body> 
</html> 